/**
 * Name: Iori Z. Pimentel
 * Date: Sep 21, 2022
 * Class Code and Course Number: 9315 - CS 112
 -----------------------------------------------------------------
 Input: Nothing
 Processes: Saying my Name 100 times using a while loop
 ------------------------------------------------------------------
 Output: My name 100 times
 Display results
 */

package prelim.activities;
public class HundredTimesDoWhile {
    public static void main(String[] args) {
        int i = 0;
        do {
            System.out.println("\tIori");
            i++;
        } while (i < 100);
    }
}
