/**
 * Name: Iori Z. Pimentel
 * Date: Aug 24, 2022
 * Problem Name: Exercise 1
 * Problem: Calling Card
 */


package prelim.exercises;

public class Exercise1 {
    public static void main(String[] args) {
        System.out.print(
                "\n\n" +
                "\t************************************\n"+
                "\t| Iori Z. Pimentel    BSCS, Year 1 |\n" +
                "\t|                                  |\n" +
                "\t|       Num: 09123567891           |\n" +
                "\t|       Email: email@gmail.com     |\n" +
                "\t|                                  |\n" +
                "\t***********************************n\n"
        );
        System.exit(0);
    }
}
